-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2850380)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(2850381,0,"91aae8a0fb823eae6a08f0a579e3e6f3c04bededbf8bcb4a257bf2ca37d146f8")
setManifestid(2850381,"6661126187281462800")
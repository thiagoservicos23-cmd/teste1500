-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2348590)
addtoken(2348590,715797643586531010)
addappid(2348591,0,"28def539c28b93a29e90e41d1e83993840db8d70da037c2ee35fb515270615f3")
setManifestid(2348591,"3543437524279407085")
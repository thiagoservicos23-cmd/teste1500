-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2840900)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(2840901,0,"ea4f551800b5ed872ef6707c3823f137a21235440b1c7e422db4ab7486a14cda")
setManifestid(2840901,"2790692351301958878")
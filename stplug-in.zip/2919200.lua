-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2919200)
addappid(2919201,0,"926e994e222b06753b643a3beb7e460a7a967952942bf23a56beba2485f4340e")
setManifestid(2919201,"68010079032096638")
-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3179260)
addappid(3179261,0,"69b9aff21823950672a38fc86653a1f9fe9a2676c8ba5018a4b9336909d4e70c")
setManifestid(3179261,"1488310422022417615")
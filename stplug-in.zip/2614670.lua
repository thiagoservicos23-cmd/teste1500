-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2614670)
addappid(2614671,0,"0f69e535aee7c7c38a6db281ad62343c9278d8f7deab2ac0baf55214a384ee84")
setManifestid(2614671,"6727813436399315765")
addappid(2614672,0,"42f3bc274725a01c45affeae9244d715a78cac1b4b8d5b776ee2441a2a387f88")
setManifestid(2614672,"398271634204917964")
addappid(2614673,0,"0950929aeed85857ae2964157a94612041427899fb142bbdc683b2b250a97f6b")
setManifestid(2614673,"1008425093137238088")
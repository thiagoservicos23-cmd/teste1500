-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3391750)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(3391751,0,"8b4c6e62bec7d55bd334cbbf5cbb2df1369ecf54c4282618ca6ce93c4fc1290e")
setManifestid(3391751,"6570508853848976463")
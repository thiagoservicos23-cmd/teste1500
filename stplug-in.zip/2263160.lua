-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2263160)
addappid(2263161,0,"539d0c4eefe266e3ee277b99f768f2fcc866c6f2c0117076875003293d55c082")
setManifestid(2263161,"6757048962061732356")
-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3461300)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(3461301,0,"a54b964a09e27defc2a0040fe84f386c51df62e45e0e9c2f3ae76c6aa350492c")
setManifestid(3461301,"1660151747644714995")
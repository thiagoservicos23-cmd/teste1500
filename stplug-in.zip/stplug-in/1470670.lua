-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1470670)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1470673,0,"d1c60e0aa577c680e738bae948fb1412459cbf46fddf1b84e34c5358b38355a1")
setManifestid(1470673,"5770828417643196384")
addappid(1470675)
-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1250220)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1250221,0,"1e95b431cf0d8e185f8f3a09259b5e1b3f7d984e280b80b887879b7feef48bb3")
setManifestid(1250221,"3393685970189730797")
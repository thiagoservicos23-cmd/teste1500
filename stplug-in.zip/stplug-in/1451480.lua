-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1451480)
addappid(1451481,0,"803908852d4442cab75b83ab01c008d5dcf536aa2a405fb9174793b0bdab56bb")
setManifestid(1451481,"3438777522887107686")
addappid(1451482,0,"5bf3185aea27548106ef1ab8ff48b60297ae9613d1ec72a033b25e7b7cd82a6d")
setManifestid(1451482,"3809472388208987352")
addappid(1451483,0,"1848ae703facf3f03b1f808b190bc2a87d84a486f9f253322d59fa26c2141df7")
setManifestid(1451483,"9037767483449703027")
-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1413210)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1413211,0,"d4750a12d4e4f69494b0d3484e35ce9043a09be0b9679c0892d8679f04e92225")
setManifestid(1413211,"4258889628856320548")
addappid(1413212)
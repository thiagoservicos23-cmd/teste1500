-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1459870)
addappid(228983)
setManifestid(228983,"8124929965194586177")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1459871,0,"3bdcf19f20fc6d6407496fba67c757b80dcbe52a6f9983b1cd0a08357e1bde7e")
setManifestid(1459871,"9065528029914611601")
addappid(1459872,0,"2320de827ceec27a43c7a1d5bc2cf5853982b7005d4fbc38df66f452485cb351")
setManifestid(1459872,"2059483092834123199")
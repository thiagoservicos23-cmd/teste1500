-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1432100)
addappid(1432101,0,"35518dbcaa6f636a0c3a6397d8d9d266052610ee877a8b31a4c0944e976a8e7c")
setManifestid(1432101,"4220389574143591608")
addappid(1432102,0,"315d2d9dfdf965c622943f646061c5491efb57272866899872e6d1884df362bb")
addappid(2485400,0,"1c2044c2a9a0d4c545c013e0cfce89c6c2b91c5918ce8cebe31523193f727399")
setManifestid(2485400,"5326685261801116899")
-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1146420)
addappid(1146421,0,"a44f6d0039da6584f371e7db0ac0d9a54735c8111da0a0a721b56da3fe229daf")
setManifestid(1146421,"6947994132941079285")
addappid(1146422)
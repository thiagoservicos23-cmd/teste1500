-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1555200)
addappid(1555201,0,"34667403a4f82b120ed98bfb1be2a9b768c14c7498f97d9bcc859076715c26d6")
setManifestid(1555201,"8427728036893538449")
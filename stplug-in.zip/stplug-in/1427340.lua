-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1427340)
addappid(1427341,0,"d34bd97cfedbb52cc77e3c4d0606ad4b71a4de56c820542f0277943ca097d0c6")
setManifestid(1427341,"7455845236841965790")
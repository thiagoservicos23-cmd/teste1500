-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1515180)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1515181,0,"91b0543ba6a3cac531bd433c837a5c6ae530118f1a49cc2e5056387b8d7dcf6a")
setManifestid(1515181,"6190060591011112407")
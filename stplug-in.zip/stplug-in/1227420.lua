-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1227420)
addappid(1227421,0,"b6b2d8d127e3866f43f46ad9cebc1b7f42c0a19958c6035e5cea0b4891d04148")
setManifestid(1227421,"2964896550259532276")
addappid(1227422,0,"8f3505bddff46cd9dca054264053200be94641b112199923282a924da118fbc7")
setManifestid(1227422,"8463379989991311402")
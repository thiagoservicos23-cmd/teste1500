-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1581931)
addappid(1797150,0,"aaec31934332d1c9fe76a2e40fcf46c652ccfd0b1447e02454d86ffa547a27ec")
setManifestid(1797150,"9168678227347832846")
addappid(1797151,0,"1d33dd771f598c5f1670ce51cca7c58ea5e6e64d3c01eb67540cffe597c2e65c")
setManifestid(1797151,"8550186480008313241")
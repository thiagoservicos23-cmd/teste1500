-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1715850)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1715851,0,"1e16e98862035f1552e0f4e6bc59d93c80a0a4f9f42d939ba044b24b0a9297d3")
setManifestid(1715851,"1684920913282180900")
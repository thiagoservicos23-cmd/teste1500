-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1602700)
addappid(1602701,0,"a3f72898a5b6ddaf0b8c716e024ea6d3f891465856f426154fc69d289d2b3a22")
setManifestid(1602701,"7288046389452465778")
addappid(1602702,0,"73ed7b0363b31a05a227e157f658a6cc250a4b4cbfebb653b21a851cf6819548")
setManifestid(1602702,"9009568846694697706")
addappid(1602703)
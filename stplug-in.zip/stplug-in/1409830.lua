-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1409830)
addappid(1409831,0,"2d48b5d0006cdc441f501a7c84673acec7aa74cd9dfb8e4fbcc98a4d8618e314")
setManifestid(1409831,"6735772450023054852")
addappid(1409833,0,"105670d6ae4ee8bef9a12fc84b72280df3ed478bbab6fb355fbe5750e391a808")
setManifestid(1409833,"2716598350131176968")
-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1222090)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1222091,0,"7e4f5a4567a2ba87f87ea6cb571c9000cfa7717322d038b9ea7ad38ddab8f666")
setManifestid(1222091,"4294669716812682684")
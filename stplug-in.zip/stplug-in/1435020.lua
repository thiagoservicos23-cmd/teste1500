-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1435020)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1435021,0,"4547271a4134521f0908713157c2d6e81224cac42d11971e6a08c5633e0ea6fc")
setManifestid(1435021,"3699360604208628951")
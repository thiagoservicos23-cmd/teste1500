-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1440710)
addappid(1440711,0,"f710a88aacb068110679ebd0de8c410752eae41f58589200dc50026b5fc95f3a")
setManifestid(1440711,"7749765415948451305")
addappid(1440712,0,"d56db7ce186513fd0848106f65c2974b12888ce72f9cc6ebbb96eac8c7ece9cc")
setManifestid(1440712,"6199043479673306857")
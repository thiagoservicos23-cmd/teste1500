-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1216300)
addappid(1216301,0,"1f35697e63cfee3242cd6e6ac2cc78127e77187711304957b1c67fa3385026c5")
setManifestid(1216301,"6576645660650767155")
addappid(1216302,0,"a1f2daf4e9420251c33f7d1294b11f0387aee010a9b4976d21f36eb3ec649539")
setManifestid(1216302,"980303387851412151")
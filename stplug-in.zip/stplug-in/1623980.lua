-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1623980)
addappid(1623981,0,"e08ebba58d9de79bf9fa1ed4bbad05079d22d283c91752e074c1be2cb1a86215")
setManifestid(1623981,"8111815638702059600")
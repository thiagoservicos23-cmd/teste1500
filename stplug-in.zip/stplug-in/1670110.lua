-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1670110)
addappid(1670111,0,"de92df1f631fa9c5178e3adcac54a6ef2abfbf1cff5f0ca3c27d0d9fdfdc5a4c")
setManifestid(1670111,"7035984460402289209")
addappid(1670114,0,"d543dc8506bcb6b963a1818a968e88fda6a8ca44562ab1db40427bf866a37415")
setManifestid(1670114,"5160173240812827027")
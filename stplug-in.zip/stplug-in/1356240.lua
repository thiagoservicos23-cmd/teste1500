-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1356240)
addappid(1356241,0,"6e5b0f9cc211866c75cfc708e8e0746037ebbb60a6aecdfa24c1883bdfd8e67c")
setManifestid(1356241,"2450532345176102000")
addappid(1356242,0,"eab61004ae3427836e39841c8114cb6d612dcf191e7346484faca46b2bc8dd3e")
setManifestid(1356242,"4008730316018690469")
addappid(1815670,0,"d444a35823093ffbdee460dee524e6e6143f5a89f0c3876afebcb2b9f3ff72e6")
setManifestid(1815670,"5331545040901085099")
addappid(2602750)
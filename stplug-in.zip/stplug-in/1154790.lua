-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1154790)
addappid(1154791,0,"e40934640b1d1f7307070e36d011f2cf6f667e2747c4b06307857eee1677beab")
setManifestid(1154791,"4482865047530519940")
addappid(1154792)
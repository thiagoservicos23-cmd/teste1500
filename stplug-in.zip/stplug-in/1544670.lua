-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1544670)
addtoken(1544670,6619880496758782539)
addappid(1544671,0,"6be119d4191cf2e1d47371b265ac5be22e0cd9487543d900a48af9cf3ee2f60c")
setManifestid(1544671,"5346312704135140659")
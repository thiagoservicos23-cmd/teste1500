-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1711400)
addappid(1711401,0,"9ad2fe12e0b4929c8590eb1011fbd77b78d172ee29f101e5ff3aedbd282c77c4")
setManifestid(1711401,"4361997439119973586")
-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1205730)
addappid(1205731,0,"bf9174e7e0775f4bcdf491373b7c6dd382cc57a69dde6bf9b49c0c14c55a34bf")
setManifestid(1205731,"1692941013507493111")
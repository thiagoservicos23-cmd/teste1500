-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1795070)
addappid(1795071,0,"3eb35a0f16faae43c2e5c36f00c97aa7024daba30b1cd107d627d36781e15c3c")
setManifestid(1795071,"4609727581100657403")
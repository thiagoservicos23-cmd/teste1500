-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1564120)
addappid(1564121,0,"a3be6a0f70023ec6b2cc6cc5caa9632d566d777e836d2459934adc82b482c8ba")
setManifestid(1564121,"8995011337344596517")
addappid(1564123,0,"a89611dd982df3dea13cf4c417e07485b634a48df0f94ef075d1267dc49ebecc")
setManifestid(1564123,"5285497910146213150")
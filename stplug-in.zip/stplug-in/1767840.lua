-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1767840)
addappid(1767841,0,"eb8c3e817aee3f974ec87047e6dc9d9b5b231dc57981c71bd2cd90efbc8b1e2a")
setManifestid(1767841,"3601717081486425832")
addappid(1767842,0,"a9df18464b81ff86ae8d92f53e7b04b6943048de73226153ebc802e6cd701e75")
setManifestid(1767842,"6637794765063208237")
addappid(1767843)
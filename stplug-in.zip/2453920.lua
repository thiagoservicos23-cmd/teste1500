-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2453920)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(2453922,0,"4bdc2af695fc38d16cb97c646d3f99593b8da7a5deae777f12b0ee0b9e1ed780")
setManifestid(2453922,"68745008802712548")
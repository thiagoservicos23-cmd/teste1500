-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2756770)
addappid(2756771,0,"0c1c614022f82e0e0bd88cecdff31567aece1953e21109bd4e7d91b1d304f67f")
setManifestid(2756771,"7319229234900918628")
addappid(2756772,0,"c5c4a4c8cb3322c1d1ff087adcf81e06729df57f37ba64586782ec5e2bd64e46")
setManifestid(2756772,"1583781845843511375")
addappid(3387950)
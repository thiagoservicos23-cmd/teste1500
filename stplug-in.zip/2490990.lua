-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2490990)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(2490991,0,"976f5204ec9850c4707672971bdcd84efeadc86cb0d62e3b76743a465fbbdee7")
setManifestid(2490991,"8128635454993681802")
addappid(2726771)
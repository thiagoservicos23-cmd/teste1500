-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2999790)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(2999791,0,"74309f5166ce0ba7de4f8f43704c41868becfeca5c9b4176479831b849a999b9")
setManifestid(2999791,"5468098457103483518")
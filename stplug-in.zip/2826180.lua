-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2826180)
addappid(2826181,0,"d45258f38e802c459905be85f6a018145885954c6c5084c3e5211cd61848929a")
setManifestid(2826181,"4732991329210555743")
addappid(2826182,0,"ee18b9b7c0913e5e5cc396b5443194a34c771f45420aae33ec4b20163b28c130")
setManifestid(2826182,"7657826162457439802")
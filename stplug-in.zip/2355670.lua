-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2355670)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(2355671,0,"0850b7b3cd26751d0cfcd7828fac0db85717f4dbd66ff14740c541b57da9835a")
setManifestid(2355671,"5583844965635397617")
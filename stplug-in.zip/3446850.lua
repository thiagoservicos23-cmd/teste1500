-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3446850)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(3446851,0,"9971739238be7f6f5a9d2fa1717819e11d4141c0c4053276656a3bf15721867d")
setManifestid(3446851,"6050134517721602030")
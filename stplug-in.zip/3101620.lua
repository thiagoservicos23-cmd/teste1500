-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3101620)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(3101621,0,"5dead3376ad70fbb830a3bf9b974daf6ef60a4eb507fc141edc35148d41eb74d")
setManifestid(3101621,"6144238905537081408")
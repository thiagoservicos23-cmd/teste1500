-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2280390)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(2280391,0,"003b98af1b727e93d43be53e54d1895151e16d713f845a8ba5293e0848ad11ee")
setManifestid(2280391,"1828829702111450250")
addappid(2280393)
-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2211170)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(2211171,0,"924f04bf42410b224830a5cbe6e5fe8ed52b2cac3a5fc909505918bbbc2670c7")
setManifestid(2211171,"3709572950844433582")
addappid(2211172,0,"879213df7df2f8d81ca40e1598d934533921f4f74471a53394c8f611bdeec23b")
setManifestid(2211172,"4720469413517974963")
addappid(3393870,0,"677987212f50458d0f106db2ca80b57787838ed4128669ed85322d2923aa79b0")
setManifestid(3393870,"6791668633663136818")
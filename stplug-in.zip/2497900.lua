-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2497900)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(2497901,0,"42d0e96d7b5440cf0b812b5ec843e2e437e28ba281e46830a2d2d7ec65c2a030")
setManifestid(2497901,"894389102672785240")
addappid(2497902)
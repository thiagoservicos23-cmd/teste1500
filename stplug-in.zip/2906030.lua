-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2906030)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(2906031,0,"7c7c8fe085d6c210bb417a7e159fbc49394934cf71b81eebb727933d83c79924")
setManifestid(2906031,"8385204807357305585")
-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2976870)
addappid(2976871,0,"dd7f2fcca7b54c05fbefb4870fbc60e3b2534bb47180fb21efb6e0da183b62d4")
setManifestid(2976871,"2943770608701930525")
-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2758290)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229007)
setManifestid(229007,"4477590687906973371")
addappid(2758291,0,"c6498dece70fddfc9e589d0136f2f6bfa130ebde5111341cec3433cbdfdacc56")
setManifestid(2758291,"8035039715247835482")
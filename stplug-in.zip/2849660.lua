-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2849660)
addappid(2849661,0,"6da7e8ab8766cd9c6ad6b6cd1b5a7b3f3522fe3af610463ecb9ea8b849b053c2")
setManifestid(2849661,"3775713330387864362")
addappid(2849662,0,"38b1c3cf425a7b3a50e66c0fe153d336026870f3fc8c168c4ba9c334af5e3f15")
setManifestid(2849662,"6188311155373395722")
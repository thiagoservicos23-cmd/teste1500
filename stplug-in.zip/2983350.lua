-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2983350)
addappid(2983351,0,"7670b3b739a093fce638fb065ab0df0c3c89ed96462a864b6fe4eebcff6bfc17")
setManifestid(2983351,"6403723809697175499")
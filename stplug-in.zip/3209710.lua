-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3209710)
addappid(3209711,0,"0f4107d655c1741d850b8f786ee52bcf21dc6ea4c1fe8065ea375f958a444f27")
setManifestid(3209711,"4429997614876746317")
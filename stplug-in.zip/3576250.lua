-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3576250)
addappid(3576251,0,"b1e5de8e0e7d8cbf73457d7fff630cc22f3d3e8d7646816f3b606a9b8a01ffa4")
setManifestid(3576251,"2099498241545486653")
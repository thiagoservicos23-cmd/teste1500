-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3104440)
addappid(3104441,0,"8c0ed31265f1a3f3a9968087cae1d37199f1705816e8dcd15855b51acfb99229")
setManifestid(3104441,"8768219858784929859")
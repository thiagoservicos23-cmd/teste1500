-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2821040)
addappid(2821041,0,"68c57d78bcf32e0c5358f25beb9eb49e1389cbc80a6c284c2f76dcda17172063")
setManifestid(2821041,"3483636154597547593")
addappid(2821042,0,"b4b49cf186299e5150afd861339c1d56971e97c94fec92e0fcb888da4ebe8467")
setManifestid(2821042,"5363371593759557874")
addappid(2821043,0,"ddf0e463c4b4df20a80d945cea8205aa89afdf2f73bfd51b83182f31688749a7")
setManifestid(2821043,"7159025239419855058")